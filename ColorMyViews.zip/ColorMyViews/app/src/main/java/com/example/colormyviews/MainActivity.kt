package com.example.colormyviews

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.databinding.DataBindingUtil
import com.example.colormyviews.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var bind: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = DataBindingUtil.setContentView(this, R.layout.activity_main)
        clicked()


    }

    private fun clicked() {
        val click: List<View> = listOf(bind.box1, bind.box2, bind.box3, bind.box4, bind.box5)

        for (i in click) {
            i.setOnClickListener { makeColored(it) }
        }
    }


    private fun makeColored(view: View) {
        when (view.id) {

            // Boxes using Color class colors for background
            bind.box1.id -> view.setBackgroundColor(Color.DKGRAY)
            bind.box2.id -> view.setBackgroundColor(Color.GRAY)

            // Boxes using Android color resources for background
            bind.box3.id -> view.setBackgroundResource(android.R.color.holo_green_light)
            bind.box4.id -> view.setBackgroundResource(android.R.color.holo_green_dark)
            bind.box5.id -> view.setBackgroundResource(android.R.color.holo_green_light)

            else -> view.setBackgroundColor(Color.LTGRAY)
        }
    }
}